// script.js
const form = document.getElementById('myForm');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');

form.addEventListener('submit', function(event) {
    if (passwordInput.value !== confirmPasswordInput.value) {
        alert('Passwords do not match!');
        event.preventDefault();
    }
});

// Add this inside the submit event listener
const passwordError = document.getElementById('passwordError');

if (passwordInput.value.length < 8) {
    passwordError.textContent = 'Password must be at least 8 characters';
    event.preventDefault();
} else {
    passwordError.textContent = '';
}