// Select the button element using its ID
const colorButton = document.getElementById('colorButton');

// Function to change the background color
function changeBackgroundColor() {
    // Generate a random color using RGB values
    const randomColor = rgb(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)});
    
    // Change the background color of the body
    document.body.style.backgroundColor = randomColor;
}

// Add a click event listener to the button
colorButton.addEventListener('click', changeBackgroundColor);